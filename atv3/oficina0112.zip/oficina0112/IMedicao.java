public interface IMedicao {
    
	public long getComparacoes();
    public double getTempo();
} 
